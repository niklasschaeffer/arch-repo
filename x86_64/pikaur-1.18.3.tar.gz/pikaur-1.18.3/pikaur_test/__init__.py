"""Pikaur testsuite."""
