```
pikaur -Vq

```


##### [Optional] Prerequisites:



##### Description:



##### Attached log:

```
pikaur -S my-precious-package --verbose --pikaur-debug


```
