#!/usr/bin/python3
"""Licensed under GPLv3, see https://www.gnu.org/licenses/"""

from pikaur.main import main

if __name__ == "__main__":
    main()
